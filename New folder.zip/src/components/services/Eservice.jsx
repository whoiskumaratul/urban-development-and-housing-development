import React from 'react'
// import { FaBeer, FaHome, FaServer } from 'react-icons/fa';

import IMAGES from '../../image/Image'
import Footer from '../Footer'
import Copyright from '../Copyright'
import Title from '../react-helmet/Title'


function Eservice() {
  return (
    // <div>Eservice</div>
   
    <div>

    <Title title="E-Services | UDHD" />

<div className='flex grid lg:grid-cols-1 m-5 mt-5 '>
        <div className=' bg-green-600 p-4  rounded-lg text-white text-xl font-semibold '>
            <h1>E-Services</h1>
          </div>
           
          </div>


          {/* <FaBeer />
          <FaServer />
          <FaHome /> */}
          

 <div className="flex grid lg:grid-cols-3 gap-2 m-2 border-2  ">


  
    

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-blue-500 " >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6 } alt="icon" /> 

</div>

<div className="w-auto bg-blue-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2 "> Online Building Plan Approve <br />भवन निर्माण स्वकृती </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div>

<div>



<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-blue-500 " >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-blue-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2"> Online Building Plan Approve <br />भवन निर्माण स्वकृती </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div>
</div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-blue-500 " >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-blue-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2 "> Online Building Plan Approve <br />भवन निर्माण स्वकृती </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-yellow-500 " >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-yellow-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2 "> Online Building Plan Approve <br />भवन निर्माण स्वकृती </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-yellow-500 " >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-yellow-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2"> Online Building Plan Approve <br />भवन निर्माण स्वकृती </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-yellow-500 " >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-yellow-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2"> Online Building Plan Approve <br />भवन निर्माण स्वकृती </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-blue-500 " >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-blue-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2 "> Online Building Plan Approve <br />भवन निर्माण स्वकृती </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-blue-500 " >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-blue-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2 "> Online Building Plan Approve <br />भवन निर्माण स्वकृती </h1>

<div className="border-t-2 border-blue-800 pt-1 ">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-blue-500 " >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-blue-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2"> Online Building Plan Approve <br />भवन निर्माण स्वकृती </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-pink-500 " >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-pink-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2"> Online Building Plan Approve <br />भवन निर्माण स्वकृती </h1>

<div className="border-t-2 border-blue-800  pt-1 ">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-pink-500 " >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-pink-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2"> Online Building Plan Approve <br />भवन निर्माण स्वकृती </h1>

<div className="border-t-2 border-blue-800  pt-1 ">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-pink-500 " >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-pink-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2 "> Online Building Plan Approve <br />भवन निर्माण स्वकृती </h1>

<div className="border-t-2 border-blue-800 pt-1 ">  <small className=" text-white" ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
</div> 


<Footer />
<Copyright />

    </div>


  )
}

export default Eservice