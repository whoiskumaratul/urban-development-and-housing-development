import React from 'react'
 

function Copyright() {
  return (
    <div>

     
    
     <div className=" text-center bg-blue-950 text-white p-4 ">
     <h1 className=' lg:text-xs/[2px]'> Copyright © Urban Development & Housing Department, Govt. of Jharkhand All Rights Reserved </h1>
     </div>
    </div>
  )
}

export default Copyright