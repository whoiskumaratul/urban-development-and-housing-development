import React from 'react'
import Title from '../react-helmet/Title'

function Birthanddeathregistrationsystem() {
  return (
    <div>
    

    <Title title="BADRS | UDHD " />
    
    Birthanddeathregistrationsystem
    
    
    </div>
  )
}

export default Birthanddeathregistrationsystem