import React from 'react'

import IMAGES from '../../image/Image'
import Footer from '../Footer'
import Copyright from '../Copyright'
import Title from '../react-helmet/Title'

function Unifiedmis() {
  return (
    // <div>Eservice</div>
   
    <div>


    <Title title="Unified | UDHD" />

<div className='flex grid lg:grid-cols-1 m-5 mt-5 '>
        <div className=' bg-green-600 p-4  rounded-lg text-white text-xl font-semibold drop-shadow-lg shadow-black'>
            <h1 className='uppercase ' >Unified Dashboard</h1>
          </div>
           
          </div>


          {/* <FaBeer />
          <FaServer />
          <FaHome /> */}
          

 <div className="flex grid lg:grid-cols-3 gap-2 m-2 border-2  ">


  
    

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-blue-500  hover:shadow-lg shadow-indigo-500/40" >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6 } alt="icon" /> 

</div>

<div className="w-auto bg-blue-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2 "> Property Tax Management System <br />सम्पति कर प्रबंधन  </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div>

<div>



<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-blue-500  hover:shadow-lg shadow-indigo-500/40" >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-blue-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2"> Property Tax Management System <br />सम्पति कर प्रबंधन  </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div>
</div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-blue-500  hover:shadow-lg shadow-indigo-500/40" >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-blue-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2 "> Property Tax Management System <br />सम्पति कर प्रबंधन  </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-yellow-500  hover:shadow-lg shadow-indigo-500/40" >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-yellow-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2 "> Property Tax Management System <br />सम्पति कर प्रबंधन  </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-yellow-500  hover:shadow-lg shadow-indigo-500/40" >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-yellow-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2"> Property Tax Management System <br />सम्पति कर प्रबंधन  </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-yellow-500  hover:shadow-lg shadow-indigo-500/40" >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-yellow-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2"> Property Tax Management System <br />सम्पति कर प्रबंधन  </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-blue-500  hover:shadow-lg shadow-indigo-500/40" >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-blue-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2 "> Property Tax Management System <br />सम्पति कर प्रबंधन  </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-blue-500  hover:shadow-lg shadow-indigo-500/40" >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-blue-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2 "> Property Tax Management System <br />सम्पति कर प्रबंधन  </h1>

<div className="border-t-2 border-blue-800 pt-1 ">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-blue-500  hover:shadow-lg shadow-indigo-500/40" >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-blue-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2"> Property Tax Management System <br />सम्पति कर प्रबंधन  </h1>

<div className="border-t-2 border-blue-800 pt-1">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-pink-500  hover:shadow-lg shadow-indigo-500/40" >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-pink-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2"> Property Tax Management System <br />सम्पति कर प्रबंधन  </h1>

<div className="border-t-2 border-blue-800  pt-1 ">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-pink-500  hover:shadow-lg shadow-indigo-500/40" >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-pink-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2"> Property Tax Management System <br />सम्पति कर प्रबंधन  </h1>

<div className="border-t-2 border-blue-800  pt-1 ">  <small className=" text-white " ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
<div>

<div className="flex grid  lg:grid-cols-2 m-2 border-2 bg-pink-500  hover:shadow-lg shadow-indigo-800/40 " >

<div className="w-24 bg-slate-600 bg-blue-500"> 
<img src={IMAGES.image6} alt="icon" /> 

</div>

<div className="w-auto bg-pink-500 text-white ">
<h1 className=" text-sm/[20px] ml-auto mr-auto mt-2 pb-2 "> Property Tax Management System <br />सम्पति कर प्रबंधन  </h1>

<div className="border-t-2 border-blue-800 pt-1 ">  <small className=" text-white" ><a href="#">Click Here</a></small>
 </div>
</div>


</div></div>
</div> 

<div>

{/* <h1 className='drop-shadow-lg shadow-black text-white bg-green-500  p-5'>fdsaf</h1> */}
</div>

<Footer />
<Copyright />

    </div>


  )
}


export default Unifiedmis