import React from 'react'
import Title from '../react-helmet/Title'
import Footer from '../Footer'
import Copyright from '../Copyright'

function Terms() {
  return (
    <div>
    
    <Title title="Terms and Condition | UDHD" />
    
  <div className='grid lg:grid-cols-1 bg-white ml-8 mr-8 mt-5 pt-5'>

    <h1 className='border-b-2 border-b-rose-600  w-full text-gray-600 font-thin pl-4 pb-4'>
        Terms and Condition
    </h1>
  </div>
  

  <div className='grid lg:grid-cols-1 ml-8 mr-8 pt-5 shadow-md   bg-white'>

    <p className='ml-10 mr-10 text-sm leading-6  hover:text-blue-600 '>Urban Development & Housing Department on behalf of Government of Jharkhand provides only the facility for transacting with Government Offices through the Internet. The service delivery is subject to the acts and rules promulgated by the Government from time to time. Electronic delivery of Government services are in compliance to the IT act 2000. The special conditions and the terms of service applicable to Internet delivery are detailed in this document.
The following terms and conditions will apply if you wish to use the Internet for availing a service. Please go through the conditions carefully and if you accept them, you may create a user and transact on the site. After creating a user you have to register the basic personal details on the site for availing a service.Please note that once you register yourself on the State Potal site, you are deemed to have agreed to the terms and conditions set forth below. If You do not agree with all these terms and conditions, you must not transact on this Website.
If a user violates the terms and conditions of use by registering more than one userid and or availing services on such multiple userids, JAPIT / Government reserves the right to deactivate all such user registration and cancel any or all services requested without any notice. Garbage / Junk values in profile may lead to Deactivation. <br />
Government's performance of this agreement is subject to existing laws and legal processes of Govt. Of Jharkhand, and nothing contained in this agreement is in derogation of Government's right to comply with law enforcement requests or requirements relating to your use of this Web Site or information provided to or gathered by SSDG with respect to such use. You agree that Government may provide details of your use of the Web Site to regulators or police or to any other third party, or in order to resolve disputes or complaints which relate to the Web Site, at Government's complete discretion.
This agreement is made between: Government of Jharkhand ("Us") and The User ("You"), the individual, whose details are set out in the Portal User Creation page. </p>
  </div>


    
  <div className='grid lg:grid-cols-1 ml-8 mr-8 pt-5  shadow-md  bg-white'>
  <h1 className='ml-5 text-yellow-500 text-lg pt-5 pb-4' >Payment Option</h1>
   
  <p className='ml-10 mr-10 text-sm leading-6  hover:text-blue-600 '>The list of payment options available are internet banking /debit card payment / credit card payment from banks that are listed when selecting each of the above options. Apart from the fee chargeable to Government against each service, bank / payment gateway transaction charges will be applicable extra. Once you register yours and your family members basic profile data as the case may be, you can apply for a service. The status of the applications submitted online shall be searched using the Status menu. SMS will be sent to your registered mobile number at different stages of processing of your application. In case of a failed transaction the user shall have no right to claim the amount. The loss on this account shall not be borne either by Government or by the Banks /Payment Gateways. </p>
</div>
    
    
    
  <div className='grid lg:grid-cols-1 ml-8 mr-8 pt-5 mb-6 shadow-md  bg-white'>
  <h1 className='ml-5 text-yellow-500 text-lg pt-5 pb-4' >Complaints Procedure </h1>
   
  <p className='ml-10 mr-10 text-sm leading-6 pb-6 hover:text-blue-600 '>You can reach us on the contact details given in the ‘Contact Us' link </p>
</div>
    

    <Footer />
    <Copyright />
    </div>
  )
}

export default Terms