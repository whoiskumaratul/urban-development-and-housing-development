import React, { useState } from "react";
import {
  FaAngleDown,
  FaFilePdf,
  FaHome,
  FaInternetExplorer,
  FaPhotoVideo,
  FaMap,
  FaAngleRight,
} from "react-icons/fa";
import { RxAvatar } from "react-icons/rx";
import {
  MdSettingsSuggest,
  MdOutlineAutoGraph,
  MdOutlinePeopleAlt,
  MdLogin,
  MdContacts,
} from "react-icons/md";

import {AiOutlineClose,AiOutlineMenu, AiOutlineUserAdd} from 'react-icons/ai'

// import Navhamburger from '../Navhamburger'
{
  /* <FaHome className='text-black ' /> */
}
import { BrowserRouter as Router, Route, useNavigate } from "react-router-dom";

import "./Navbar.css";

function Navbar() {
  const navigate = useNavigate();

  const [navbarOpen, setNavbarOpen] =  useState(true);
  

  const toggleSidebar = () => {
    setNavbarOpen(!navbarOpen);
  };

  return (
    <div>
      <header className="">
        <nav className={`xs:grid-cols-10 lg:grid-cols-1 xs:text-xs     ${navbarOpen ? 'block' : 'hidden '} md:hidden lg:block lg:w-full md:w-12 `}>
          <ul className="flex bg-[#167004] text-white shadow-md  shadow-slate-600 rounded-md text-sm  ml-4 mt-1 mr-4 p-4">
            {/* <Nav.Item icon={<Task />}>
                    Practice </Nav.Item> */}
            <li
              className=" font-bold hover:text-[#FF6A00]  pl-5 text-[16px]   cursor-pointer "
              onClick={() => navigate("/")}
            >
              {" "}
              <FaHome className="float-left mt-1 ml-1 pb-0.5  " />
              &nbsp;Home
            </li>

            <span className="dropdown">
              <li className="font-bold  hover:text-[#FF6A00]  pl-5 dropbtn cursor-pointer  ">
                {" "}
                <FaAngleDown className="float-right mt-1 ml-1" />
                <RxAvatar className="float-left mt-1 ml-1 pb-0.5 " />
                &nbsp;About Us
              </li>
              <span className="dropdown-content border-2 border-green-500 space-y-1 pt-1 pb-1  font-semibold   ">
                <li
                  className="  anker  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer "
                  onClick={() => navigate("/aboutus")}
                >
                  About
                </li>
                <li
                  className="  anker  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer  "
                  onClick={() => navigate("/functions")}
                >
                  function
                </li>
                <li
                  className="  anker  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer "
                  onClick={() => navigate("/maps")}
                >
                  {" "}
                  <FaMap className="float-left  " />
                  &nbsp;Maps
                </li>
              </span>
            </span>

            {/* <span className='text-3xl '>‸</span> */}

            <span className="dropdown">
              <li className="font-bold hover:text-[#FF6A00]  pl-5 dropbtn  cursor-pointer ">
                <FaAngleDown className="float-right mt-1 ml-1" />
                <FaFilePdf className="float-left mt-1 ml-1 pb-0.5 " />
                Documents
              </li>
              <span className="dropdown-content border-2 border-green-500 space-y-1 pt-1 pb-1  font-semibold ">
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1  cursor-pointer"
                  onClick={() => navigate("/sankalps")}
                >
                  Resolutions (Sankalp)
                </li>
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1  cursor-pointer"
                  onClick={() => navigate("/tenders")}
                >
                  Tenders
                </li>
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1  cursor-pointer"
                  onClick={() => navigate("/notices")}
                >
                  Notices
                </li>

                <span className="dropdowntwo">
                  <li className=" anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1  cursor-pointer  dropbtntwo  ">
                    {" "}
                    Important Documents{" "}
                    <FaAngleRight className="float-right  ml-1" />
                  </li>
                  <span className="dropdown-contenttwo border-2 border-green-500 space-y-1 pt-1 pb-1  font-semibold   ">
                    <li
                      className="  ankertwo  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer "
                      onClick={() => navigate("/acts")}
                    >
                      Acts
                    </li>
                    <li
                      className="  ankertwo  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer  "
                      onClick={() => navigate("/rules")}
                    >
                      Rules
                    </li>
                    <li
                      className="  ankertwo  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer "
                      onClick={() => navigate("/policy")}
                    >
                      Policy
                    </li>
                    <li
                      className="  ankertwo  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer "
                      onClick={() => navigate("/byelaws")}
                    >
                      Bye Laws
                    </li>
                    <li
                      className="  ankertwo  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer "
                      onClick={() => navigate("/policy")}
                    >
                      Guidelines
                    </li>
                    <li
                      className="  ankertwo  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer "
                      onClick={() => navigate("/policy")}
                    >
                      Operational Manuals
                    </li>
                  </span>
                </span>

                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1  cursor-pointer"
                  onClick={() => navigate("/notification")}
                >
                  Notifications
                </li>

                <span className="dropdowntwo">
                  <li className=" anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1  cursor-pointer  dropbtntwo  ">
                    {" "}
                    Financial Documents
                    <FaAngleRight className="float-right  ml-1" />
                  </li>
                  <span className="dropdown-contenttwo border-2 border-green-500 space-y-1 pt-1 pb-1  font-semibold   ">
                    <li
                      className="  ankertwo  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer "
                      onClick={() => navigate("/acts")}
                    >
                      Budget
                    </li>
                    <li
                      className="  ankertwo  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer  "
                      onClick={() => navigate("/rules")}
                    >
                      Annual Financial Stmt
                    </li>
                    <li
                      className="  ankertwo  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer "
                      onClick={() => navigate("/policy")}
                    >
                      Audited Annual Financial Stmt
                    </li>
                    <li
                      className="  ankertwo  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer "
                      onClick={() => navigate("/byelaws")}
                    >
                      Internal Audit Reports
                    </li>
                    <li
                      className="  ankertwo  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer "
                      onClick={() => navigate("/policy")}
                    >
                      Credit Ratings
                    </li>
                    <li
                      className="  ankertwo  text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1   cursor-pointer "
                      onClick={() => navigate("/policy")}
                    >
                      Jharkhand Accounting Manuals
                    </li>
                  </span>
                </span>

                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1  cursor-pointer"
                  onClick={() => navigate("/sanctionorders")}
                >
                  Sanction Orders
                </li>
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1  cursor-pointer"
                  onClick={() => navigate("/minutesofmeeting")}
                >
                  Minutes of Meeting
                </li>
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1  cursor-pointer"
                  onClick={() => navigate("/officeorder")}
                >
                  Office Orders
                </li>
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1  cursor-pointer"
                  onClick={() => navigate("/citysanitationplan")}
                >
                  City Sanitation Plans
                </li>
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1  cursor-pointer"
                  onClick={() => navigate("/masterplan")}
                >
                  Master Plans
                </li>
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1 cursor-pointer "
                  onClick={() => navigate("/servicelevelbenchmark")}
                >
                  SLB(Service Level Benchmark)
                </li>
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1  cursor-pointer"
                  onClick={() => navigate("/departmentcircular")}
                >
                  Departmental Circulars
                </li>
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1  cursor-pointer"
                  onClick={() => navigate("/suo")}
                >
                  Suo Motu Circulars
                </li>
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1 cursor-pointer "
                  onClick={() => navigate("/finalreports")}
                >
                  15th FC Final Reports
                </li>
              </span>
            </span>

            <span className="dropdown">
              <li className="font-bold hover:text-[#FF6A00]  pl-5 dropbtn   cursor-pointer">
                {" "}
                <FaAngleDown className="float-right mt-1 ml-1" />
                <MdSettingsSuggest className="float-left mt-0.5 ml-1  pb-[3px] text-xl  " />{" "}
                Schemes & Programs
              </li>
              <span className="dropdown-content border-2 border-green-500 space-y-1 pt-1 pb-1  font-semibold ">
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1 cursor-pointer"
                  onClick={() => navigate("/ranchismartcity")}
                >
                  Ranchi Smart City
                </li>
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1 cursor-pointer "
                  onClick={() => navigate("/amrut")}
                >
                  AMRUT
                </li>
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1 cursor-pointer "
                  onClick={() => navigate("/swachhbharatmission")}
                >
                  Swachh Bharat Mission
                </li>
                <li
                  className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1 cursor-pointer "
                  onClick={() => navigate("/nationalurbanlivelihoodmission")}
                >
                  NULM
                </li>

                <li className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1 ">
                  PMAY
                </li>

                <li className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1 ">
                  Housing Schemes
                </li>

                <li className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1 ">
                  Namami Gange
                </li>

                <li className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1 ">
                  Urban Transport
                </li>
              </span>
            </span>
            
            <li
              className="font-bold hover:text-[#FF6A00]  pl-5 text-[16px]  cursor-pointer"
              onClick={() => navigate("/eservices")}
            >
              <FaInternetExplorer className="float-left mt-1 ml-1 pb-0.5 " />
              &nbsp;e-Services
            </li>

            <span className="dropdown">
              <li className="font-bold hover:text-[#FF6A00]  pl-5 dropbtn cursor-pointer">
                <FaAngleDown className="float-right mt-1 ml-1" />{" "}
                <FaPhotoVideo className="float-left mt-1 ml-1 pb-0.5 " />
                &nbsp;Gallery
              </li>
              <span className="dropdown-content border-2 border-green-500 space-y-1 pt-1 pb-1  font-semibold ">
                <li className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1 ">
                  Gallery
                </li>
                <li className="  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1 ">
                  Media
                </li>
              </span>
            </span>

            <li
              className="font-bold hover:text-[#FF6A00]  pl-5 text-[16px]   cursor-pointer"
              onClick={() => navigate("/unifiedmis")}
            >
              <MdOutlineAutoGraph className="float-left mt-1 ml-1 pb-0.5 " />
              &nbsp;UNIFIED MIS
            </li>

            <span className="dropdown">
              <li className="font-bold hover:text-[#FF6A00]  pl-5 dropbtn cursor-pointer">
                {" "}
                <FaAngleDown className="float-right mt-1 ml-1" />
                <MdOutlinePeopleAlt className="float-left mt-1 ml-1 pb-0.5 " />
                &nbsp;Careers
              </li>

              <span className="dropdown-content border-2 border-green-500 space-y-1 pt-1 pb-1  font-semibold ">
                <li className=" font-thin  anker text-black  dropbtn  hover:underline pl-2 pr-1 text-xs pb-1 pt-1 ">
                  Requirements
                </li>
              </span>
            </span>

            <li
              className="font-bold hover:text-[#FF6A00]  pl-5 text-[16px] cursor-pointer"
              onClick={() => navigate("/login")}
            >
              <MdLogin className="float-left mt-1 ml-1 pb-0.5 " />
              &nbsp;Login
            </li>

            <li
              className="font-bold hover:text-[#FF6A00]  pl-5 text-[16px]  cursor-pointer"
              onClick={() => navigate("/contactus")}
            >
              <MdContacts className="float-left mt-1 ml-1 pb-0.5 " />
              &nbsp;Contact Us
            </li>

 
            <li className="font-bold hover:text-[#FF6a00] pl-5 text-[16px] cursor-pointer sm:block lg:hidden "
            >
               <button className="md:block flex pl-2 "  onClick={toggleSidebar}  >
        
        {navbarOpen ? <AiOutlineClose size={20}  /> : <AiOutlineMenu size={20} />} 
                                   
       </button>
            </li>

            {/* <span> <FaHome /><li> Check with icons</li></span> */}
          </ul>

         
        </nav>
        
<div className='flex sm:block lg:hidden '>
      {/* w-full on h1 className */}
      <div> 
      <button className="p-3.5"  onClick={toggleSidebar}  >
        
       {navbarOpen ? <AiOutlineClose size={20}  /> : <AiOutlineMenu size={20} />} 
       
      </button>
      </div>

         
        </div>
      </header>
    </div>
  );
}

export default Navbar;
