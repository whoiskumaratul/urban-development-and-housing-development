const onOptionChangeHandler = (event) => {
  const selectedValue = event.target.value;
  console.log("User Selected Value - ", selectedValue);
  alert(selectedValue);

  // Redirect to a specific URL based on the selected value
  if (selectedValue === "option1") {
    window.location.href = "https://example.com/page1";
  } else if (selectedValue === "option2") {
    window.location.href = "https://example.com/page2";
  } else if (selectedValue === "option3") {
    window.location.href = "https://example.com/page3";
  }
};





import { Link } from 'react-router-dom';

const onOptionChangeHandler = (event) => {
  const selectedValue = event.target.value;
  console.log("User Selected Value - ", selectedValue);
  alert(selectedValue);
};

// In your component's render method or JSX
return (
  <div>
    <select onChange={onOptionChangeHandler}>
      <option value="option1">Option 1</option>
      <option value="option2">Option 2</option>
      <option value="option3">Option 3</option>
    </select>

    {/* Link components for navigating to different URLs */}
    <Link to="/page1">Page 1</Link>
    <Link to="/page2">Page 2</Link>
    <Link to="/page3">Page 3</Link>
  </div>
);
