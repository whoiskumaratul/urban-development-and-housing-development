import React from 'react'
import { MdArrowCircleRight } from 'react-icons/md';
import Title from './react-helmet/Title';

function Urbanlocalbodiesinformation() {
  return (
    <div>

<Title title="ULBI | UDHD "/>

    <div className="flex grid lg:grid-cols-4 gap-5 m-5 mt-6 ">

<div className="text-sm bg-white text-green-600 hover:text-white hover:bg-yellow-500 border-2 border-red-600 h-10 mt-auto mb-auto text-center p-2"> <MdArrowCircleRight className='float-left     pb-[3px] text-2xl text-red-500 '/>Urban Local Bodies Information</div>

   
<div className="text-sm bg-white text-green-600 hover:text-white hover:bg-yellow-500 border-2 border-red-600 h-10 mt-auto mb-auto text-center p-2"><MdArrowCircleRight className='float-left    ml-5  pb-[3px] text-2xl text-red-500 '/>Executive Officers</div>

<div className="text-sm bg-white text-green-600 hover:text-white hover:bg-yellow-500 border-2 border-red-600 h-10 mt-auto mb-auto text-center p-2"><MdArrowCircleRight className='float-left    ml-5  pb-[3px] text-2xl text-red-500 '/>City Mission Managers</div>


   <div className="text-sm bg-white text-green-600 hover:text-white hover:bg-yellow-500 border-2 border-red-600 h-10 mt-auto mb-auto text-center p-2"><MdArrowCircleRight className='float-left    ml-5  pb-[3px] text-2xl text-red-500  '/>City Managers</div>

 
</div>

    </div>
  )
}

export default Urbanlocalbodiesinformation