import React from 'react'

function Schemesandprogramscommon(props) {
  return (
    <div>
    
    
<div className='grid lg:grid-cols-1 ml-5 mr-5 mt-5 '>
        <div className=' bg-[#38C11C] p-4   text-white text-xl font-thin drop-shadow-lg shadow-black'>
            <h1 className='' >{props.header}</h1>
          </div>
      
          </div>
    </div>
  )
}

export default Schemesandprogramscommon