const IMAGES = {
    image1: new URL('./jhklogo.png', import.meta.url).href,
    image2: new URL('./sliding.jpg', import.meta.url).href,
    image3: new URL('./csp4.jpg', import.meta.url).href,
    image4: new URL('./diramit.png', import.meta.url).href,
    image5: new URL('./dmadir23.jpg', import.meta.url).href,
    image6: new URL('./bank.png', import.meta.url).href,
    image7: new URL('./contactbanner.jpg', import.meta.url).href,
    image8: new URL('./smartcitysoln.jpg', import.meta.url).href,
    image9: new URL('./cleanindia.jpg', import.meta.url).href,
    image10: new URL('./Amrutlogo.jpg', import.meta.url).href,
    image11: new URL('./amrutcitiespopulation.png', import.meta.url).href,
    image12: new URL('./downloader.png', import.meta.url).href,
    image13: new URL('./managementstructure.png', import.meta.url).href,
    image14: new URL('./pmayAugust.jpg', import.meta.url).href,
    image15: new URL('./beautifulindia.jpg', import.meta.url).href,
    image16: new URL('./ganga.jpg', import.meta.url).href,
    image17: new URL('./modiji.jpg', import.meta.url).href,
    image17: new URL('./bus.jpg', import.meta.url).href,
    image18: new URL('./bpams.jpg', import.meta.url).href,
    image19: new URL('./csp.jpg', import.meta.url).href,
    image20: new URL('./cluster1.jpg', import.meta.url).href,
    image21: new URL('./cluster3.jpg', import.meta.url).href,
    image22: new URL('./blinking.gif', import.meta.url).href,
    image23: new URL('./rsc1.jpg', import.meta.url).href,
    image24: new URL('./rsc2.png', import.meta.url).href,
    image25: new URL('./pmayimage.jpeg', import.meta.url).href,

    image26: new URL('./gallery1.jpg', import.meta.url).href,
    image27: new URL('./gallery2.jpg', import.meta.url).href,
    image28: new URL('./gallery3.jpg', import.meta.url).href,

    image29: new URL('./gallery4.jpg', import.meta.url).href,
    image30: new URL('./gallery5.jpg', import.meta.url).href,
    image31: new URL('./gallery6.jpg', import.meta.url).href,

    image32: new URL('./gallery7.jpg', import.meta.url).href,
    image33: new URL('./gallery8.jpg', import.meta.url).href,
    image34: new URL('./gallery9.jpg', import.meta.url).href,
    image35: new URL('./gallery10.jpg', import.meta.url).href,

    image36: new URL('./gallery11.jpg', import.meta.url).href,
    image37: new URL('./gallery12.jpg', import.meta.url).href,
    image38: new URL('./gallery13.jpg', import.meta.url).href,
    image39: new URL('./gallery14.jpg', import.meta.url).href,
    image40: new URL('./gallery15.jpg', import.meta.url).href,
    image41: new URL('./gallery16.jpg', import.meta.url).href,

    image42: new URL('./gallery17.jpg', import.meta.url).href,
    image43: new URL('./gallery18.jpg', import.meta.url).href,
    image44: new URL('./gallery19.jpg', import.meta.url).href,
    image45: new URL('./gallery20.jpg', import.meta.url).href,
    image46: new URL('./gallery21.jpg', import.meta.url).href,
    image47: new URL('./gallery22.jpg', import.meta.url).href,

    image48: new URL('./gallery23.jpg', import.meta.url).href,
    image49: new URL('./gallery24.jpg', import.meta.url).href,
    image50: new URL('./gallery25.jpg', import.meta.url).href,
    image51: new URL('./gallery26.jpg', import.meta.url).href,
    image52: new URL('./gallery27.jpg', import.meta.url).href,
    image53: new URL('./gallery28.jpg', import.meta.url).href,
    image54: new URL('./gallery29.jpg', import.meta.url).href



}

export default IMAGES